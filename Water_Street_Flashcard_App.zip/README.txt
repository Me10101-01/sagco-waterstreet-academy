Open index.html locally, or upload this folder to Netlify Drop / GitHub Pages / Raspberry Pi web server.
